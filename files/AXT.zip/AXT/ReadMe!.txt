ReadMe!.txt  --  AXT v1.0 for WinAmp 2.x
----------------------------------------

Finally finished this skin. 
Because of some trouble with my monitor and other projects,
I did a long time over this one.
The actual idea of this skin came from an older skin of me,
called Amp X-treme.
People who know that skin will see some returned things,
and it is actually based on it.
So that's why the name: Amp X-treme Two; AXT.
Really simple :).
Tryed not to over-detail the skin like many other people 
do too much lately I think.
Enjoy the skin!

--------------------
Created in/with:
1280*1024
32 Bpp
Adobe Photoshop 6.0.0.1
MS Paint
MS Notepad
--------------------

________________________________________

Site: http://www.smar.nl
General Mail: info@smar.nl
About skins: skins@smar.nl
________________________________________


Greetz,

-=SMAR=-


(D) 2001 - SMAR Designs
Registered Design
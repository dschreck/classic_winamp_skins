Cool Blue skin for WinAmp by Blue Jay

Any comments are welcomed.

Blue Jay
bj@netlinkmail.com
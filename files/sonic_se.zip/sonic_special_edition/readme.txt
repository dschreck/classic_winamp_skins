Sonic : Special Edition.
------------------------
   This is my first skin that I made using
Photoshop.All the graphic is made by Photoshop.
The text documents is edited by Notepad.

   Hope you will enjoy using this skin.
------------------------------------------------
   Please replace the startpage for Winamp
Minibrowser with 'winampmb.htm' that included
in this skin.
------------------------------------------------
Author  = Snecx
E-mail  = snecx@yahoo.com
Webpage = http://www.geocities.com/snecx/winamp/
------------------------------------------------
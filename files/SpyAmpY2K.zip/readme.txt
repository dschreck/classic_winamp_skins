Spyamp Y2K

Just in for the new Millennium.

After been a big fan of Spyamp from the start and through it's modifications up until version 6, I still saw area for refinement and went to work on Spyamp 008 Version 7 but with the Millennium on us I deceided to make a Y2K version.

Much of the original Spyamp had fallen away between 007 and 008 but there were still some buttons and bugs to be cleared up. I really liked the winshade buttons and while they progressed to the Playlist, Equalizer and Minibrowser they were neglected in the Main amp. I added slightly modified versions here with a new Minimizer button to add to the appeal.

From there I cleaned up the text a bit as it was difficult to read in 1024x768 resolution. Changed some of the wording and also made the memory popup buttons in the Equalizer the same as the rest.

Next I went on to the Winshademodes and made it to look more like a unit when stacked on top of each other.

I also changed the minibrowser load page to include the history of the Spyamp. Some Dynamic HTML effects added to the page make it a bit more active on loading. The page ('winampmb.htm') can be extracted to the winamp folder and when the browser is active the page will load in your Minibrowser. Along with this you will need to extract another file ("animate.js") into the same folder for the Dynamic HTML effects to work.

I have included the visulisation plugin that came with version 6 of Spyamp 008. I myself am not one for plugins as I prefer to surf while listening to the music, but this is a great plugin and is interesting to watch for a few minutes.

Hope you like the modifications.

Any comments, please feel free to mail me at wayne.baxter@ast.co.za
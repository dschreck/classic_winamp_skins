ZergAmp v1.0
----------------------			
Zerg skin from the game StarCraft. Decided to give the Winamp User a different, scary look. My second skin, this was thought up because I didn't see many excellent StarCraft skins around. I thank everyone for downloading this skin, and I hope to make more in the future. Again thanks to <tahros@yahoo.co.kr> for the tips.
----------------------
<jasong_sg@yahoo.com>

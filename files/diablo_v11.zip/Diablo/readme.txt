Skin name: Diablo Amp
Release version: 1.1
Description: High color skin based on the Blizzard game Diablo. Includes images of
in-play objects all over the place. All parts, including cursors, skinned.
Category: Game
Author name (or alias): Novi Productions
Author email address: ian@aatech.com
URL of Novi Productions home page: http://www.veganplanet.com/noviprod

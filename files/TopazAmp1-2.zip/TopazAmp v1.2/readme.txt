--[ TopazAmp v1.2 ]--


about this skin
==========================

(for v2.x of Winamp)
This is my first attempt at a Winamp skin, based on the design my upcoming web site.

  -- some bugs from v1.0 fixed
  -- thanks to Wolf [http://surf.to/guf, hhc977@edu.ghs.dk] for fixing some v1.1 bugs

--[ distribute freely, but please don't modify the images. thanks ]--

==========================

[ (c) 1999 Kelly McLarnon                  ]
[ website: http://topazdesigns.com         ]
[ (personal: http://topazdesigns.com/~klm) ]
[ email: klm@topazdesigns.com              ]



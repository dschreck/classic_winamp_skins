========================================================
 "Versatile"    Skin for Winamp 
========================================================

                                                  Version 1.0

Versatile is "fully winamp skin", with main, equalizer, playlist, mini
browser, avs and cursors entirely skinned.

For best results use this skin with Winamp 2.5+
and in truecolor mode.

The skin was made with MSPaint, PhotoShop 5.5 and Microangelo.
For the Region.txt, I have used Winamp TransTrace and Winamp
Skin Maker 1.20 for general purpose.	

This is the best that I actually can do... If you like a little bit of my 
work, please leave or send by E-mail a little comment...
I hope you enjoy it.

Date first release:  10.22.2000

Many thanx to my friend Barta, for his patient in bugs hunt.

Francesco Maria Lanciani, Rome (Italy) 
 
E-mail:   francolanciani@tin.it

========================================================
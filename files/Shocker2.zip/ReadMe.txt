                          Shocker2
                  created by Larry Tennison
                           v.1.0



This skin began as just an update to the earlier skin "Shocker" 
and excalated into what you see now.  It ended up being so much
different from the origional, I decided just to make it it's 
own.  Thus it became the sequal.  Everything seemed to be 
operational, so there will probab;y be no updates unless I find 
something wrong with it mechanically.

The visualization was intended to be used with normal/thick bars.
If you are using a different setting like fire/thin, this is why
the vis. may look a little funny.

The origional Shocker skin is downloadable from the Official WinAmp
site as well if you would like to what started this one.  I promise 
it isn't much to look at, but then it was created using nothing 
but MSpaint.....Ohh wait, so was this one.  In any case,  if you would 
like to send any feedback, questions, or skin ideas, my e-mail is listed 
below:

Wezzterman@aol.com
33866099 (ICQ#) 
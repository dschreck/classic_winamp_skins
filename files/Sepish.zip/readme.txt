Sepish - Skin For Winamp

version: 1.0 (4-21-2000)

Transparent skin for Winamp,  I just wanted to know is it possible to make a round skin... Yes, but some parts will be missing... I recommend you to put the main window on top and the equalizer below it so the skin looks round.

BTW... if you want to know how to make a skin transparent open the region.txt in this skin (you need Winzip or some another program like that to open the zip file), I made some notes which may help you to understand that list of numbers...

Enjoy!

___KaMi___
Email:kaum@mbnet.fi
Homepage: http://koti.mbnet.fi/kaum/
http://koti.mbnet.fi/kaum/skins/sepishe.htm
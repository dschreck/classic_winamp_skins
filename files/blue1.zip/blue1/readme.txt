Winamp 2.x skin
Something Blue (release one)

	Author:		Matt Brown
	Purpose:	Boredom
	Based on:	Nothing

----------------------------------------------------------------------

// Requirements:
Fingers

// install notes:
Throw the *.zip file into your \winamp\skins\ directory, don't 
unzip it.

// Contact:
E-mail : MBZoso@aol.com
Web Page : http://members.tripod.com/MBZoso

// Other notes:
This took a long damn time, especially the transparency part.  
Be impressed, be very impressed.


// Other skins:
DennysAmp, MattAmp, and CamelAmp

// File list:
some stuff

Thanks for downloading.
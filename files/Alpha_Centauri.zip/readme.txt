========================================================
 "Alpha Centauri" Skin for Winamp 
========================================================

                                                  Version 1.0

This is my skin number nine.

It is "fully winamp skin", with main, equalizer, playlist, mini
browser.

For best results use this skin with Winamp 2.5+
and in truecolor mode.

I hope you enjoy it.

Date first release:  09.25.2000

Many thanx to my friend Barta, for his patient in
bugs hunt, for the nice cursors and for the splendid 
idea of the shadows-mode amazing docking pack!
(First main, then playlist and last the equalizer all
in windowshade mode, vertically placed !)

Francesco Maria Lanciani, Rome (Italy)  
E-mail:   francolanciani@tin.it


========================================================
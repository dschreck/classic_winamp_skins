This folder contain cursors for your InsomniAmp 1.1.
To use these cursors with your InsomniAmp skin, simply put them
in the same folder as he rest of the InsomniAmp files.
(Which is probably namned InsomniAmp 1.1).

In this folder you can also find a .html file called
winampmd.html. I recommand you to place this file in the same folder
as you can find the winamp.exe file. (The folder which Winamp is installed to).
In that way the minibrowsers look will match better with the insomniAmp skin.

REMsleeper

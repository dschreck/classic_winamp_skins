*** InsomniAmp 1.2 ***

THANKS TO...

Some of the parts in this skin is borrowed from a the Angedelo skin.
If ou want to contact him, his address is: angedelo@club-internet.fr


SOME INFORMATION & RECOMMENDATIONS

This new skin is dedicated to all of you out there, sitting up late at nights, 
working, surfing or... & is listening to .mp3 music. If you didn�t already know, insomnia
means that you have sleeping problems.


THE SKIN WILL LOOK THE BEST IF YOU CHANGE...:

* If you look in the folder in which you installed this skin to you can find a subfolder
  called cursors. Its up to you if you choose o use them. Some people might find them anoying.


Thank you for using this skin, hope you�ll like it.
If you want to contact me, please send a mail to: nordh@algonet.se


Anyone is free to use this skin. Also feel free to use it, edit it or give it away
as long as it is for non-commercial, non-profit purposes.



Charlie Nordh "REMsleeper" nordh@algonet.se
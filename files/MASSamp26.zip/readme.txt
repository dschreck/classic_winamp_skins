MASSamp 2.6 for Winamp 2.x

It' s my second skin and it contains the main window, the playlist, the equalizer and the minibrowser.
I used a little of Illustrator and Photoshop to make my skin but mostly Paint.
I remade this skin from my old one, MASSamp 2.5.
I hope you like it

thanks for downloading my skin.

Alexandre Masson
Alemass@hotmail.com
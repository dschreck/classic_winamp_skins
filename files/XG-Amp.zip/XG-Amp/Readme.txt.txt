Hi, thanks for downloading XG Synth-Amp.  This is my second Winamp skin, the first being IBM Amp.  I put
in alot more time on this one (3 months vs. 3 days for IBM Amp), so hopefully it is decent.

If you have any problems, suggestions, or questions, feel free to contact me.

- Prashant
email:  psistla@vt.edu


-----------

Name of Skin:  XG Synth-Amp

Release Version:  1.02

Description:  This skin is loosely based on Yamaha's YXG-70 SoftSynthesizer software.  Other than the color scheme and logos, it's original work.  The Equalizer is pretty slick :)

Category:  Either Computer/OS or HiFi

Author Name (me):  Prashant Sistla

Email Address:  prashant@vt.edu

Homepage:  http://members.xoom.com/Hifi311/


Fossil 2002 v2.0 - Released January 1st 1999
   

TABLE OF CONTENTS

   1.   INTRODUCTION
   2.   INSTALLATION
   3.   ABOUT
   4.   CREDITS
   5.   CONTACT
   6.   LEGAL
    	

1. INTRODUCTION

Thank you for downloading this skin. Make sure you have at least Winamp 1.8, otherwise you
are not able to use this skin as your Winamp interface. Check www.winamp.com for the latest
release of Winamp.


2. INSTALLATION

Unzipping to your winamp/skins directory will create a subfolder storing all data. Launch Winamp, go to the option-menu and use the skin-browser to select the skin.

For users of Winamp 2.04 or higher it's enough to copy the ZIP-File to the winamp/skins
directory.


3. ABOUT

This is my first Winamp skin. It was designed to look like the Fossil 2002 watch, which is a remake of the famous Pulsar LEDs. My first intention was to make a modification of Hydro's Onkyo skin, but after getting into it I changed my plans. Everything except the interface's texture and the buttons was created by me. Please check the credits for more.


4. CREDITS

Idea and realization: Jan T. Sott
Silver texture      : G�tz Bockstedte

Buttons taken from Hydro's Onkyo skin for Winamp


5. CONTACT

E-Mail: yathosho@altavista.net
URL   : http://members.xoom.com/animeye/winamp


6. LEGAL

Fossil 2002 is a trademark of Fossil, Inc.

Winamp is Copyright � 1997-1998 Nullsoft, Inc. and Justin Frankel.
Winamp is a trademark of Nullsoft, Inc.
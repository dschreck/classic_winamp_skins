This is my first skin. The next one must be better.
Hope you use and enjoy it.
It has a East Egg title!

My name: Sam Leex(Lixiang)
Email: leex@163.net
|--------------------------------------------|
|CALVIN & HOBBES SKIN FOR WINAMP 2.xx        |
|                                            |
|Created by Joe Hardy   hardy@northnet.com.au|
|Version 1.0                       31/07/1999|
|--------------------------------------------|

My first attempt at creating a Winamp skin (it looks
like it too :), based on Calvin and Hobbes.

Calvin and Hobbes is � Bill Watterson.

Some images and the font used in the title bar were
borrowed from Calvin and Hobbes at Martijns
(http://www.okidoki.nl/calvin_and_hobbes/) ... hope
you don't mind Martijn :-)

Any suggestions, comments, raves, hate mail, etc please
send them to me. You might like to make suggestions on 
improving the C&H theme by making the buttons, sliders 
etc relate to the comic.

BTW, I know the minibrowser looks half-baked, I just
wanted to get the thing finished and I figured this
has _got_ to be the least used feature!

Special Thanks to:
------------------

Alex Pullar who's the biggest C&H freak I know ;-)
Dad for occasionally offering helpful suggestions
Mum, even though she still can't figure out why I'd want
to waste my time making something like this ...

INSTALLATION INSTRUCTIONS
-------------------------

Do we really need 'em? Oh well ...

Winamp 2.0
----------

Unzip the contents of this zip file into a folder
under the Winamp skins directory, for example
Program Files\Winamp\Skins\Calvin and Hobbes

Winamp 2.4+
----------

Simply stick this zip file in the Winamp skins directory.

Open it up in Winamp by hitting Alt+S and select
calvinskin (or whatever you named the folder if you're
using v2.0).

Enjoy! :)

Joe Hardy
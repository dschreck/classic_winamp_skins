
p l a s m a   V  2 . 2
-------------------------------------------------

hi there. this is my new winamp skin (uhhh, that 
was a lame starter...).


anyway:

i included a nice goodie this time (to give this 
darn minibrowser something like functionality ;P).


you can make _plasma.html your default page in
the winamp mini browser. just execute 

_make_plasma_default.bat

this script renames the standard winamp_mb.htm to
winamp_mb_old.htm and copies _plasma.html on its 
place

to restore the original settings, execute

_restore_default.bat


misery is not liable for any damage this .bat files
may cause. nothing should happen, and nothing may,
but it had to be said anyway =) 

anything skinrelevant is found in this document
(its called _plasma.html)
if you don't want to make it your default, be my
guest, but at least you may take a look at it.




--------------------------------------------------

winamp 1.x/2.x

	* miseryamp 			1.0
	* phreak 				0.667
	* xtended 				1.0
	* stainless				2.0
	* metropolis 			2.01
	* pandemonium			1.0
	* coldbringer			2.01
	* boost VIII			2.0
	* schubduese			2.0
	* asmith.net			2.0
	* crystal bastard			2.0
	* zorg				2.0
	* plasma				2.2

k-jofol

	* wintermute			2.0
	* phong				1.5
	* happy2				2.0
	* vibrocentric			1.0

sonique

	* battleangel			1.0

xxcalc

	* sub/lo			2.0

quake II

	* haujobb			1.0


distibute this skin freely, but don't delete the 
readme. manipulators and modifiers of this skin 
will be eaten by myself personally :-0.

-------------------------------------------------
misery, 15.08.99

web: 	http://misery.subnet.at
mail:	misery_in_motion@mindless.com

(c) m i s e r y   i n   m o t i o n   ( 9 9 ) 
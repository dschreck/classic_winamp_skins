LaxAmp.
-------
This skin is created by me,Snecx using only 2 programs.
*Windows 98 Paint and Notepad.

  This skin is made for Winamp version 2.20 and above.
I hope this skin will be the best for Winamp and all other
Winamp lover.My mission is to make the best Winamp skin.

  And also please extract the .htm file that included in this
skin to your Winamp directory.There will be a same file but
just replace it.Then in the MiniBrowser window click refresh.
Now the MiniBrowser in fully skinned.

Snecx.
snecx@yahoo.com
#ICQ=30663122

** You may distribute this skin freely as  **
**long as this readme.txt file is included.**
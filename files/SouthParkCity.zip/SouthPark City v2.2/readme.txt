SouthPark City is a Skin for Winamp 2.x
-----------------------------------------------------------------------
Version 2.2
-----------------------------------------------------------------------
designed by Matthias Rasim
-----------------------------------------------------------------------
V1.0 Mainbitmap created
V1.5 Equalizer & Playlisteditor designed
V2.0 Minibrowser skinned
V2.1 New Numbers & some small changes
V2.2 Some small changes in the player & the equalizer
-----------------------------------------------------------------------
Thank you for downloading my Southpark Skin,
Hope you will enjoy it!!
-----------------------------------------------------------------------
For ideas or bugs mail me at matthias@rasim.de
-----------------------------------------------------------------------

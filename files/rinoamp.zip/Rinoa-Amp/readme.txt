Rinoa Amp v2.0

This Winamp skin was made by me on 19-NOV-1999

The skin is based on Rinoa Heartilly from Final Fantasy VIII

To install the skin, simply unzip all the files into your winamp skins folder,
run winamp and select the skin RINOA-AMP.

Enjoy!

If you wish to ask me any questions, do so at:

swordheart@gundam.com

Thanks a lot,

Swordheart

HOMEPAGE: http://www.geocities.com/aftercol/
\____________________/
| WINamp98 plus! 4.0 |
/--------------------\

 By Ahmed Arebi							1.1.2000
-----------------------------------------------------------------------------
                                                             
  Just an update of the last version
  ----------------------------------------------------------------------------
  - Some modification
  - Minibrowser is added



 	
 Email : a_arebi@hotmail.com

 www.a-arebi.8m.com
  ----===QUAKE 3 ARENA SKIN====----
             version 1.0
              
     Esta � minha primeira skin 
  portanto se existir alguns BUGS 
  ser�o solucionados em uma nova vers�o. 
 
            Made in Brazil
               Torres/RS
                                 By BITO                  
 


            
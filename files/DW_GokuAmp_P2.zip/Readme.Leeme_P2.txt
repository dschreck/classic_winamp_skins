

	Producto de Daniel's Wolrd
	  Buenos Aires Argentina
		Goku@mp.ZIP


Espa�ol:

Hola, Saludos a los que vean este documento. 
Feliz A�o 2000.
Este es mi nuevo amp: GoKu@mp, hay algo que tengo que contar sobre 
el, me sent� un d�a o dos y lo termine, pero no le saque el cartel del
Playinlist y le agregue uno igual al minibrowser, ha! (me gusto).

Lamentablemente esta es una verci�n de baja CALIDAD GRAFICA ya que la 
de buena calidad ocupa mucho. Si quieren obtener esta ultima version 
totalmente gratis (GRATAROLA) mandenme un E-MAIL a:
mmcross@latinmail.com 
y en breve se las mandar�.

Gracias por Download mi Goku Skin!

PD: Las imagenes son totalmente afanadas de internet y o artbooks de mis
amigos.
PD: Para hacer esta skin utilice el Corel� Draw� 8 (copia, no original),
el Corel� Foto Paint (Copia) y el MS Paint (Copia, porque mi version de
windows tampoco es del todo legal)


Inglish:

Hello www's friends and Pirates. Here it is the new winamp's skin for 
Dragon ball's fans. 
Hapy new year 2000.

This is a poor cuality version, because the full cuality version is 
too long. if you want it, send me a E-Mail to:
mmcross@latinmail.com and I'll send it as soon as possible. 
Thanks for downdload my Goku skin!

For create this skin i used Corel� Draw� 8, Corel� Foto Paint and MS Paint
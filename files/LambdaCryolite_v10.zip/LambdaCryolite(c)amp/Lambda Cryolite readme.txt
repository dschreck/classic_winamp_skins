****************************************************************************************************************
THIS I A FREEWARE, FEEL FREE TO DISTRIBUTE IT, BUT AS A FAVOR, PLEASE DISTRIBUTE IT *WITH* THIS README.TXT FILE.
THANK YOU.  - amp
****************************************************************************************************************


Lambda CRYOLITE v1.0 by amp - Released January 17th - 2000
   

   TABLE OF CONTENTS

	1.   INTRODUCTION
	2.   INSTALLATION
	3.   ABOUT
	4.   OTHER PRODUCTS
	5.   CREDITS
	6.   CONTACT
	7.   LEGAL
    	

1. INTRODUCTION

	Thank you for using this skin. Make sure you have at least Winamp 2.5, otherwise you are not able to use
	this skin as your Winamp interface. The interface is designed with very subtle shadings to convey
	realism and looks best on a true-color (24-or 32-bit) display with a resolution at (min) 1024-768 for best
	result.
	
	Check www.lambda.subnet.dk for updates and for other skins made by me. 
	And check also www.winamp.com for the latest release of Winamp. - Winamp is now !!!Freeware!!! (v2.5c)
	


2. INSTALLATION

	Unzipping to your winamp/skins directory will create a subfolder storing all data. Launch
	Winamp, go to the option-menu and use the skin-browser to select the skin.
	For users of Winamp 2.04 or higher it's enough to copy the ZIP-File to the winamp/skins
	directory.


3. ABOUT
	
	This is LambdaCRYOLITE:	Texture: 	Main,Main winshade, Eq, Eq winshade, Pl,Pl winshade, MB
					Regions:  	no use of regions, - didnt fit this skin
					Transperency:	no use of regions, - didnt fit this skin 
					AVS:		will might be included in a newer version

	INTENSIONS with LAMBDA series: "To make the best looking skins and all-textured as possible 
									                 for WINAMP 2.x an above".   
	I chose to use the name Lambda because; in physic it's the symbol that represents the length of waves, - 	like sound waves. All my production are related with the symbol Lambda, - expect the name to return 
	to your screen soon!
	
	Look out for my new skin: Lambda ZEUS - approaching soon!
		
	For further information my website is:			www.lambda.subnet.dk
	or write to me at my email address:        		Lambda_amp@hotmail.com.    


4. OTHER PRODUCTS
	Here is a full list of my skins for Winamp:

	OLD *REMOVED* Winamp 1.X Skins	

	1.	Gauss			(removed)
	2.	Lambda			(removed again due to the introduction of winamp2.x)

	The *New* LAMBDA Series for Winamp 2.x and above

	1.	Bentzen 2.0
	2.	Bentzen 2.1	(Update underway to 2.5 - new buttons,position bar,display and more...)
	3.	NEUTRON 1.6
	4.	DELPHINEE 1.1	(Update underway to 1.5 - new buttons ect... =
	5.	SPAWN		(Cancel)
	6.	CRYOLITE 1.1
	7.	ZEUS 		(under construction...)

5. CREDITS and Acknowledgements

	Creator: Jesper Bentzen (amp)
	

6. CONTACT

	I would be VERY glad if you would write to my and tell my your opinion about my skin, that will help me
	in further productions, so that I can make even better skins.
	If you have any comments, please do not hesitate. Write to me.
		
	E-mail address: Lambda_amp@hotmail.com


7. LEGAL

	Please, do not change my skin without my permission, I have spent days in the process of making
	this skin, and I don not want to see it being abused.

	Lambda Series is a trademark of Bentzen.

	Winamp is Copyright � 1997-1999 Nullsoft, Inc. and Justin Frankel.
	Winamp is a trademark of Nullsoft, Inc.
Si-Amp With AVS (1.2), by Simon Mansley
Originally Submitted: 21st April 2000

01/06/2000
I resubmitted, and was happy to get 5 stars, so
here's v1.2 - now with AVS as suggested by the
reviewer. :) I also noticed that while fixing
1.1, I mucked up a few things - so they're re-
repaired. This should be the last I submit of
Si-Amp, but who knows - Winamp might grow an
extra window.

24/05/2000
Just a few improvements to the main window, and
to the minibrowser. Also, a friend pointed out
a couple of slight mistakes in my first version
so I fixed them. Also, it now looks nicer in
256 colours.

21/04/2000
My first skin... learned quite a few things from
making this. My next will hopefully be better :)


Feel free to pass this skin around to friends.

Email: simans@madasafish.com
This skin was built listening to Winamp. :)

ReadMe!.txt Cold Mist 1.1 for WinAmp 2.x                              (27-01-2001)
----------------------------------------

I sayd with my last skin that it was my final for WinAmp 2.x.
Well, here I am again, bringin' a new one =).
Just can't seem to let go of it.

Anyways, first I wanted to thank the people at WinAmp's Skin Dev List,
I couldn't figur out a name for it, they told me their idea's, and so
because of those ideas I came up with this name.

The skin is created in/with:


-- 1280*1024 with 
-- 32bpp
-- Windows ME
-- Adobe Photoshop 6
-- MS Paint
-- Notepad

Not much, eh?


* Update v1.0 to v1.1 - What changed? *

Cbuttons        -  Faded to the side
Shuf/rep/eq/pl  -  Put an extra color in between.
On/Auto         -  Same as above.



Greetz to all who knew me already and to the ones who are gonna know me ;).


-=SMAR=-


WebSite - http://www.smardesigns.com
        - http://smar.hypermart.net
        - http://smardesigns.glow.nl

E-Mail  - SMAR2K@hotmail.com
        - info@smar.nl (dunno if it stay's working!)
        - Webmaster@smardesigns.com

Mail me if you find any bugs in the skin, or have some ideas about updating etc.


(D) 2001 - SMAR Designs

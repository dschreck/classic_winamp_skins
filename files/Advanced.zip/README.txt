    +--------------------------------------------+
    |  Advance Audio skin v1.2 for WinAmp v2.1   |
    |  Bob Zormeir  9/98   bobz@serv.net         |
    +--------------------------------------------+


This is a skin for WinAmp v2.1 of WinAmp. Everything but
new the playlist and equalizer skins should be compatible 
with earlier versions.  I welcome questions, comments and 
suggestions.

- Bob


Installation
------------
1. Copy or move Advance.zip to the WinAmp Skins directory. 
2. Unzip the file to generate the 'Advanced' directory and 
   necessary files for the 'Advanced Audio Player' skin.
3. Launch WinAmp, and type Alt-S for the Skin Browser.
4. Double-click on 'Advanced.'
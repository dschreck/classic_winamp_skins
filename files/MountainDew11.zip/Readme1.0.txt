
MountainDew v1.1
for Winamp 2x

Created By : DrewskiZ
Contact : drewskiz@hotmail.com
Date : January 23, 2000
Updated : January 30, 2000

I have seen many softdrink skins but none for Mountain Dew.  While
making this one I realized why.  The logo, which I took a digital
photo of from a case of the stuff, is difficult to work into a skin
nicely.  I had to modify it a little, but it works well.

I skinned the windowshades to be docked together because this is how I 
often use winamp while working.  If anyone wants it with normal in-
dividual windowshades let me know and I will gladly put out an updated
version.  Any other comments or requests send to: drewskiz@hotmail.com

Other skins by DrewskiZ : Outback (available from 1001winampskins.com
                                   or skinz.org)
New in version 1.1 :

-Position bar modified 2:23 PM 01/26/2000 
 by pabo aka Brian N. Godfrey who's skins can also be 
 found at the above mentioned sites.  Thanks for the most excellent can  of Dew Pabo!

-Changed sliders for vol and bal and load button.

-Fixed Problem with background colors matching in certain screen res.



Drew Ziemke 2000
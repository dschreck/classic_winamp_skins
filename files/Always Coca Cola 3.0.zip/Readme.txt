[ Always Coca Cola 3.0 (Holiday Collector Version)] - [ Copyright CraShOveR / FMC ]

====
Thank you for downloading Always Coca Cola 3.0 skin for WinAmp.
This is my new Coca Cola Skin, and this time I created it starting for the base skin...
It was made especially for the Holidays 1998 :)
If you have any question, or have any good idea about the Always Coca Cola skin feel free to
email me at 

CraShOveR@hotmail.com


[Version]

beta 1.0:
- first try...

1.5:
- some improvements in the buttons

2.0:
- New background
- Visu colors fixed
- EQ and PL buttons redesigned
- New shuffle and repeat buttons
- some other few stuff...

3.0:
-Complete new design
-Finally has the Playlist and Equalizer (For all of you that asked me).

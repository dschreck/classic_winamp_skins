Bang & Olfsen v2.10 - Released April 10th 1999
   

TABLE OF CONTENTS

   1.   INTRODUCTION
   2.   INSTALLATION
   3.   ABOUT
   4.   CREDITS
   5.   CONTACT
   6.   LEGAL
    	

1. INTRODUCTION

thank you for downloading this skin. make sure you have at least winamp 2.09, otherwise you
are not able to use this skin as your winamp interface. check www.winamp.com for the latest
release of winamp.


2. INSTALLATION

unzipping to your winamp/skins directory will create a subfolder storing all data. launch
winamp, go to the option-menu and use the skin-browser to select the skin.

for users of winamp 2.04 or higher it's enough to copy the zip-file to the winamp/skins
directory.


3. ABOUT

this is my first Winamp skin. some parts of the skin was created by bleach from Jan T. Sott's  
"Fossil 2002" winamp skin. please check the credits for more.

4. CREDITS

idea and realization: bleach
Mini Browser Skin development: bleach & Dust Devil (riaanm@yahoo.com) 
basic design: Jan T. Sott

5. CONTACT

e-mail: bleach@webmail.co.za 
URL   : http://www.bang-olufsen.com (check out their awsome equipment!!!)

6. LEGAL

Bang & Olusen and B&O is a trademark of Bang & Olusen, Inc.

Winamp is Copyright � 1997-1999 Nullsoft, Inc. and Justin Frankel.
Winamp is a trademark of Nullsoft, Inc.

Yata yata yata...
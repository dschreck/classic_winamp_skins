mp3 dl script by DenizDizman
s6263@sg.edu.tr UIN:20801133
----------------------------

This is an *advanced* script for downloading/leeching mp3 from IRC

Features:

+CTCP MP3 Grabber 
+CTCP MP3 favourite artits catcher and downloader
+Automatic Notice tracker
+Automatic one-click Msg requesting
+Automatic Shutdown/disconnect timer
+Integrated MP3 player and Playlist
+Auto get timed MP3 requesting
+Que management
+Tracking of requested / received MP3s
+Terminal Sytle look and feel


installing is easy: 
it works under mirc 5.91. It doesnt have any version checking so it should
work on other versions too. Just copy the ini files and launch mirc. I would recomend you
to do a setup first.


I am looking for good mirc coders to enhance the Script! Contact me via email/icq!!

EOF


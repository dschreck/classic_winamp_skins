Skin Name 	= Light Amp	
Skin Verison 	= v1.0
Skin Author	= Eliseo Quirarte Gonzalez (For designer X)
Author Email	= equirar@prodigy.net.mx



Special Features:

All parts of this winamp skin are done.
Included:
	Winamp Main 		- Ok
	Winamp Equalizer        - Ok
	Winamp Playlist		- Ok
	Winamp Minibrowser	- Ok
	
To use a Light Amp Skin By Eliseo & designer x Follow the Instructions...




Note. If your using a version prior to 2.X you may not be able to see the full Skin package.


Step I.  Extracting the Skin
1.  If version greater than 2.x (No Need to extract just place the zip in your skins Directory)
2.  You will need winzip or an equivalent software package to install the skin if prior to Winamp is version 1.X.
3.  Extract the Skin to a directory on Computer.  Preferred is as follows:
	a.  C:\Program Files\Winamp\Skins\ {If default was used to install winamp)
	b.  or Another Directory.
		i.  If another directory is used you will have to point the skin browser to use an alternate skin directory location.
		ii. To do this Press Alt+S and Click the button "Set Skins Directory".

	c.  Proceed to Step II.

Step II.  Using the Skin
1.  Open Winamp
2.  Press Alt+S
3.  Select the Skin you wish to use.




Enjoy them.     Light Amp is designed and created by designer X
	Light Amp has been created whit:
        MGI Photo Suit, Power Point, Magic and Paint


Please do not Modify to Publish, Light Amp and all them features are trade mark:
2000-2001 Designer X all rights reserved.

Tanks...            Eliseo Quirarte Gonzalez.


 Tip...
*** The file "bakground" is an extra file to use in desktop wallpaper, for best view of the skin.
	


The Matrix WinAmp Skin Version 1.0
-------------------------------
****************************************
*******    What is the Matrix    *******
****************************************


Author : Spider
e-mail : mauls_saber@hotmail.com

****************************************

Installation

Step 1:  Make a New Folder in your WinAmp Skins Directory Called TheMatrix.

Step 2:  Extract all the files in the TheMatrix.zip into the directory you made in step 1. 

Step 3:  Open WinAmp Click in the top left Corner go to Skins Choose TheMatrix.

Step 4:  Enjoy!!!

***************************************

Here it is all you Matrix fans the skin you have been waiting for. 
To get the full effect stick the equalizer and the Play List Editor under the Main Player.

-The Spider
----------------------------------------------------------------
      LIQUID - Version 1.1 - README
----------------------------------------------------------------

Created by
SIMON EICHHORN - JokerSE
Pforzheim, Germany
E-Mail: JokerSE@GMX.de


Version 1.1 
Some Improvements in the Main Window


Version 1.0 Released
As I planned to create a new Skin
for Winamp, I was Inspired by the
Skin "Pocketamp" (Gary Calpo). 
Although the Basic Design is quite
boring, the excessive use of trans-
parency makes it look amazing. So I
decided to create a skin with a 
similiar use of transparency, but 
(I think so) better Design. 
What you see is the result.

Send me your Comments !

Bye
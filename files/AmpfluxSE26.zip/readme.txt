 AMPFLUX SPECIAL EDITION v2.6 
     -- an update to v2.5 --

+ Designed by:
  cRaCkhEaD (c)2000
  darkinferno@mailcity.com

+ Design Notes:
  released 1.28.00
  based on the AmpFlux Blue Ampskin + All previous versions of AmpFlux SE
  created for Winamp v2.5+
  suggested display @ 16-bit color depth or higher

+ Features:

  (v1.0)
  fully digital interface
  advanced slidebar integration
  lighting effects and vertical color gradients
  face plate applied --> looks kinda like a pager case 

  (v2.0)
  made a few modifications to the playlist editor from v1.0
  added minibrowser support in v2.0 

  (v2.1)
  slightly altered the playlist editor shade-mode so the buttons do not dance around

  (v2.2)
  entire skin underwent cosmetic surgery
  fixed a small flaw in the playlist editor scrolling bar slider
  all edges were redone giving it a much less rigid look especially in doublesize mode

  (v2.3)
  corrected the time remaining display bug --> the minus sign is now shown
  inserted one line of black to the left side of the spectrum background so it is now even
  lightened a few pixels near the right edge of the spectrum
  changed a few lines of color in the LCD area of the equalizer
  made improvements to the gradient in the upper right of the playlist editor
  added and moved some pixels in the number 8 in the nums_ex.bmp

  (v2.4)
  correctly centered all EQ sliders
  moved the presets (a.k.a. memory) button to the left four whole pixels in the equalizer
  increased the gap between the DB markings and the preamp slider
  pushed the left edge of the playlist's spectrum to the right one pixel to make it even

  (v2.5)
  very minor cosmetic corrections to the playlist window
  altered the gradient next to the spectrum of the playlist editor when it is extended

  (v2.6)
  finally corrected the left most spectrum gradients in the playlist editor window
  this is the eighth and final release of the ampflux se series

+ Installation Notes:
  extract files into the skins folder (e.g. C:\Program Files\Winamp\Skins\AmpFlux SE v2.6)
  install the ocraext.ttf font file into the windows font folder (e.g. C:\Windows\Fonts)
  load winamp and select AmpFlux SE v2.6 from the skins window

+ Attributes - ampfluxse26.zip:
  total 20 files
  packed @ 153 kbytes
  unpacked @ 1,050 kbytes
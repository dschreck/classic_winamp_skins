Jackall WinAmp Skin by Jesse Tan
--------------------------------

Hi there..thanks for download my winamp 2.x skin.This is
the first time i doing it so it not so good,but i hope 
you like it.If you don't like it,just don't use it right?

Althought i already double check all the skin, and i hope
i didn't miss anything..kekekek :oP , but if i do miss 
something, please e-mail me ok? You can reach me at :

jackall_t@yahoo.com       or
jesse_tsm@hotmail.com



How to use WinAmp skin:
--------------------
If you have a Winamp 2.x, just put this zipfile into the /skins folder
under the /winamp one, then press ALT+S with WinAmp running and choose 
the skin from the list
that will pop up.

If you have a previous version:

Unzip all the zipfile into a folder under /skins one.

i.e.: /winamp/skins/Jackall

Every skin needs to be unzipped in a different folder


----------------------------------------------------------
This skin is Copyright 1999 by Jesse Tan, you could freely 
distribute this skin but You can't put it on commercial 
collects or other commercial stuff without my permission.




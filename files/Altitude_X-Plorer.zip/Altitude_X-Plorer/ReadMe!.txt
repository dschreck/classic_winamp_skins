ReadMe!.txt Altitude X-Plorer v1.0 for WinAmp 2.x
-------------------------------------------------

Hello there, and thank you for downloading my skin.

Ok, to start off with; I have said to the guys at lotsofskins.com 
that the next skin that I would make (this one that is), it would be uploaded to
there site first. And I just hate to break my word. So it's uploaded there first.
They are doing everything to make there site a great skins and wallpapers site,
so please visit them =).

Ok, to continue about the skin;
I've been working on a lot of stuff lately. 
Recently updated my site, with a new look, and I'm also working on a new Pioneer skin
(requested by a lot of people) and a friend asked me to make a Sony X-Plod car audio
skin. But this has been te first one to be finished.

Created in/with:
1280*1024 32Bpp
Windows2000 Professionel
Adobe Photoshop
MS Paint

The story behind the skin:
Ever wanted to see the height of you music file? You can with this skin!
Just load you music file into the WinAmp program and the skin will see 
the height! It's crazy, it's cool!*

*This story is fictional, not for real. It actually just plays the file, nothing more.
It's like a normal skin, but with a different idea behind it.


That's all folks!

Kind regards,

Stefan (a.k.a -=SMAR=-)


Website:
http://www.smar.nl
E-mail:
info@smar.nl
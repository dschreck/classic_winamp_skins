Skin name: Diablo II
Release version: Released!
Description: Evil Has Survived! Features Diablo himself (from a print ad), the game box and
the Battle.net interface. All parts skinned, including cursors and the WVS, and I included
the necessary font. New: put a pic of Diablo in place of the Necromancer, updated the
Wanderer's face with the final graphic, and made various tweaks throughout. Even includes
the dreaded Battle.net Chat Gem.
Category: Game
Author name (or alias): Novi Productions
Author email address: ian@aatech.com
URL of Novi Productions home page: http://www.veganplanet.com/noviprod

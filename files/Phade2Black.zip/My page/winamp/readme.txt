Fade2Black skin version 2.0 (that means i finally skinned all the windows lol)

This skin has previously appeared on www.skinz.org only.

This skin is 3d or futuristic i guess. It wasn't made for a category.

I created this skin for winamp 2.x because I wanted a skin that would be simple enough to look good even at very high resolution, wouldn't be loud as all hell, and would look good against black. I use it as my default because I like it.

-ClockworkOJ
jam48@po.cwru.edu
http://poke.at.stomped.com
EULA=http://poke.at.stomped.com/eula.txt

Enjoy!
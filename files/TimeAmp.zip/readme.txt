---------------------------
TiMeAmp beta v1.00
15 novembre 1998
---------------------------

Le TiMeAmp est un th�me cr�� pour �tre utilis� avec la version 2.0 ou plus du logiciel
de musique Winamp (http://www.winamp.com).

Le TiMeAmp a �t� cr�� dans le but d'offrir aux visiteurs du Monde de Ti-M� une occasion
de retrouver chez eux et en permanence un coin de notre monde. Bien qu'il soit de couleurs
et de style diff�rent que celui de la page web, il est un aper�u de ce que vous verrez
bient�t sur le Monde.


CARACT�RISTIQUES
----------------

Version v1.00

- Equilizer termin� et fonctionnel.

Version v0.03

- Corrections de l'image "mono".
- Corrections du bouton sup�rieur gauche.
- Modification du Winamp "barre".
- Animation de la barre de son.

Version v0.02

- Corrections de quelques probl�mes dans les images.
- Barre de r�duction termin�e.

Version v0.01

- Premi�re version de l'interface.
- Seul le menu principal fonctionnant.
- Plusieurs images non-faites.


AIDE
----

D�compressez les fichiers dans le r�pertoire principal de Winamp. Les fichiers se placeront
automatiquement dans les bons r�pertoires.

Pour voir l'interface, appuyez sur ALT-S dans Winamp et choisissez "timeamp".


CR�DITS
-------

Design de l'interface TiMeAmp 
� Laurent Hogue

Design de la page web 
� Laurent Hogue

Contenu de la page web principale
� Bruno Fiset, Benoit Plouffe, 
� Jean-Fran�ois Brault et Laurent Hogue

Id�e originale
  Bruno Fiset et Jean-Fran�ois Brault
-===================================================-
     Protoss-Amp v.1.1.   by  -=Executeleader=-
-===================================================-

This is a skin for WinAmp v1.8 and higher.

This skin is from the Benneten ArtEntertainment.

Comments? Suggestions? E-mail: Ben-@gmx.de

February 26, 1999 modifiled July 16, 1999 by
Bennet Schulte.

Installation
------------
Automatic-ACE-Installer
Now, launch WinAmp, type Alt-S or enter the Options and
choose Select Skin, then click on Protoss-Amp.
                                        DRAGON Z amp V3.0 AMP


Hey! This is my first skin but newer! Well sort of... It's more of a build on. I've made most of
 
the buttons see through so more of the pictures can be seen. If you downloaded DragonballZV1.0amp 

or DragonballZ V2.0amp  then in 3.0 you will be able to see Vageta's head (V2.0) and face and

almost every title bar is see through (V3.0). Some other improvements to ,now the PL and MB have 

new colors YEAH!!.Others Not to noticible. Hope you enjoy! Oh ya New name!! 





e-mail me if you comments ,suggestions ,requests of something e.g. another anime, car,etc..

(include e-mail adress for requests) ,etc.

PLEASE DON'T SEND E-MAIL IF YOU ARE JUST GIONG TO SAY MY SKIN SUCKS. Thankyou.

aperson52@excite.com 
compiled a long long time ago in a galaxy far far away...(In other words I forgot)
I'm not really sure if anybody reads these...
By:Daniel R.



Please Note: I did not make ANY changes in the Region.txt I'm not that good at the Tech stuff.

















��MAD�!

						THE END.
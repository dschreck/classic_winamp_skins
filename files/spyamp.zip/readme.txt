I liked this skin so much that i adapted it for winamp 2.03.

Just unzip the file in ...winamp\skins\spyamp.

Enjoy!
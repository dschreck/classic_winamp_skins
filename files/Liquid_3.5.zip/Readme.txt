----------------------------------------------------------------
      LIQUID - Version 3.5 - INFO
----------------------------------------------------------------

Created by
SIMON EICHHORN - JokerSE
Pforzheim/Munich, Germany
E-Mail: JokerSE@GMX.de

Version 3.5
April 26th 2001
- Slight changes in transparency
- Better contrast


Version 3.0
November 27th 2000
- Added totally new transparency to the main window.
  Looks like sunglasses on your desktop 8-)
- Redesigned Equalizer
- Changed some things in the playlist

Version 2.0
September 26th 2000
- I made an allover facelifting of Main Window, Equalizer 
  and Playlist
- Further improvements in transparency

Version 1.9
Juni 18th 2000
- Numbers in Main window look better now
- Improvements in transparency
- Improvements in playlist

Version 1.5
May 7th 2000
- Skin for AVS Window added
- some slight improvements


Version 1.1 
April 9th 2000
- Some Improvements in the Main Window


Version 1.0 Released
March 30th 2000
As I planned to create a new Skin
for Winamp, I was Inspired by the
Skin "Pocketamp" (Gary Calpo). 
Although the Basic Design is quite
boring, the excessive use of trans-
parency makes it look amazing. So I
decided to create a skin with a 
similiar use of transparency, but 
(I think so) better Design. 
What you see is the result.

Send me your Comments !

Bye
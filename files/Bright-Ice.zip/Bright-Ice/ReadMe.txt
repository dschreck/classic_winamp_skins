ReadMe!.txt  --  Bright-Ice v1.0 for WinAmp 2.x
-----------------------------------------------

Whoa!
Now this one took some time to finish.
I started working on a different skin,
but I didn't like it much.
So I tried something else and this is what
it become.
This isn't a typical "metal" skin.
It's the display that is what makes this skin.
My thoughts where to make something different
than the usual metal skin.
The bright blue display is very common as a
backlight for watches and other displays.
Even though, it is rarely used on WinAmp skins,
so I thought I'd give it a wirl :).

Maybe I'll make more different display colors,
but I wanna see how this one is going.

--------------------
Created in/with:
1280*1024
32 Bpp
Adobe Photoshop 6.0.0.1
MS Paint
MS Notepad
--------------------

________________________________________

Site: http://www.smar.nl
General Mail: info@smar.nl
About skins: skins@smar.nl
________________________________________


Greetz,

-=SMAR=-


(D) 2001 / 2002 - SMAR Designs
Registered Design
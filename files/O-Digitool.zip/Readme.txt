  _   _   _   _   _   _   _
_- -_- -_- -_- -_- -_- -_-
  _-  _-  _-  _-  _-  _-  _
_- |^^~~~Digitool~~~^^| -  _-
  _-  _-  _-  _-  _-  _-  _
_- -_- -_- -_- -_- -_- -_-
18-05-20(C)00  

Hey
I hope you like this slick looking skin.

I've updated this skin with some new nice colors and done something with the few mistakes i found!

It was entirely done with PSP 5.0, with credits to Kung-Fu Digitool.

Visit http://go.to/T@O to get more skins (designed by me).

Thanks!
|^Zen^|
ta_ormaasen@hotmail.com

Contact me at E-Mail or mIRC undernet
Channel: woodstock.com


- Clarion AutoPC
- v2 basically looks smoother
- Designed to look like Clarion's AutoPC 
- Used to be Brand Name skin I dont nowe what it is now
- Designed by Neokat (me)
- neokat@netzero.net (Free Internet)
- http://neokat.bizland.com

This is an update to my FIRST winampskin.
I wanted to do something different instead of the 1,000,000 BORING 
Sony skins.  Some of them are good, but most of them suck. I think 
it looks kool. If you dont, or you want to give me some advice, 
then email me with some feedback. 

Just place this zipfile into the skins folder to use it!

bye now!
Alien[X]ated v1.4
--------------------
Phycho...at least that's what i think... :)

[update]: Well not much have been changed in this ver.....i just smothed the skin in general-just fixed some small details.... :))

[update]: Cleaned up the whole skin......added the mini eq and minibrowser

[update]: Made the sliders smoother....small details also fixed..

X-caponius' skins for Winamp2x
--------------------
Red X 866	v2.0
X-manus		v1.2
Chiller X	v1.0
Protestor X	v1.0
Chiller X ltd	v1.0
Qirex 		v1.0
X-tinted	v2.0
Cosmical X	V1.4
Xenon 		v1.5
LiquidXtention	v1.0
X-tinted X09	v1.1
REversus X	v1.0
Xtd 9199	v1.0
Adrenalin X02	v1.1
Reclaim X02	v1.0
Oporium X02	v1.0
Alien[x]ated	v1.4
Etract [gen]x	v1.0
Blithex		v1.0
Biogradable	v1.0

Enjoy this skin...but do not copy and graphics from it.....give this to anyone u want but plz include the readme : )

If u want to make any comments on this skin mail me "caponpower@yahoo.com"

Website: http://xhrc.homepage.com

Cya soon....
